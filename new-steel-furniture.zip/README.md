# New Steel Furniture - Official Showcase Landing Page

A modern, high-converting, fully responsive landing page designed specifically for **New Steel Furniture** manufacturing & wholesale business.

---

## 🚀 How to View & Test on Your Device

### Option 1: Open Directly in Your Mobile / Browser
Run this command in Termux to open the file directly in your browser:
```bash
termux-open /data/data/com.termux/files/home/new-steel-furniture/index.html
```

### Option 2: Run a Local Web Server
If you have Python installed (`pkg install python`):
```bash
cd ~/new-steel-furniture
python3 -m http.server 8080
```
Then open `http://localhost:8080` in Chrome / your browser!

---

## ✨ Features Included

1. **Modern Industrial Aesthetics**: Clean slate & metallic blue color theme, crisp typography, and responsive layout that looks great on mobile, tablet, and desktop.
2. **Interactive Product Catalog**:
   - Filterable tabs: Steel Almirahs, Office Storage, Industrial Slotted Racks, Metal Beds, and Multi-Door Lockers.
   - Click "View Specs" on any product to open a detailed specification modal.
3. **Live Quote / Price Estimator**:
   - Customers can pick a product, choose steel gauge (18, 20, 22 gauge), select finish (Solid, Dual-tone, Woodgrain), and adjust quantity with automatic multi-unit/wholesale discounts.
   - Generates an instant WhatsApp booking link with their exact specifications.
4. **Manufacturing & Anti-Rust Tech Process**:
   - 5-step breakdown highlighting prime CRCA steel, CNC bending, and the 7-tank anti-rust powder coating treatment.
5. **Customer Reviews & FAQ Accordion**:
   - Addresses common buyer questions regarding gauge thickness, rust protection, custom dimensions, and bulk orders.
6. **Lead Generation & WhatsApp Integration**:
   - Direct click-to-WhatsApp buttons with pre-filled inquiries.
   - Quick contact form with instant validation.
   - Floating WhatsApp and quick call buttons for mobile users.

---

## 🛠️ How to Customize

- **Phone Number & WhatsApp**: Open `index.html` and `script.js` and replace `919876543210` with your actual 10-digit mobile number.
- **Address & Showroom Location**: Update the contact address in `index.html` under the `<section id="contact">` section.
- **Prices & Catalog Items**: Edit the product cards in `index.html` and update the `productDatabase` in `script.js`.

---

## 🌐 How to Put It Online for Free

You can deploy this website for free in under 2 minutes using:
- **GitHub Pages**: Push this directory to a GitHub repository and enable Pages in repository settings.
- **Netlify Drop**: Drag and drop the `new-steel-furniture` folder into [Netlify Drop](https://app.netlify.com/drop).
- **Vercel**: Deploy using the Vercel CLI or Git connection.
