#!/usr/bin/env bash
set -e

echo "=========================================="
echo "  Deploy New Steel Furniture to GitHub    "
echo "=========================================="
echo ""
echo "1. Go to https://github.com/new and create a new PUBLIC repository."
echo "2. Copy your repository HTTPS URL (e.g., https://github.com/your-username/new-steel-furniture.git)"
echo ""
read -p "Enter your GitHub repository URL: " REPO_URL

if [ -z "$REPO_URL" ]; then
  echo "Error: Repository URL cannot be empty."
  exit 1
fi

cd "$(dirname "$0")"

# Remove existing origin if any
git remote remove origin 2>/dev/null || true

# Add remote
git remote add origin "$REPO_URL"
git branch -M main

echo ""
echo "Pushing code to GitHub..."
echo "Note: When prompted for password, enter your GitHub Personal Access Token (PAT)."
echo ""

git push -u origin main

echo ""
echo "=========================================="
echo "Code pushed successfully!"
echo "Now enable GitHub Pages:"
echo "1. Go to your repo on github.com"
echo "2. Click Settings -> Pages"
echo "3. Under 'Branch', select 'main' and click 'Save'"
echo "Your website will be live in 1-2 minutes!"
echo "=========================================="
