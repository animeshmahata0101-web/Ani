/**
 * NEW STEEL FURNITURE - INTERACTIVE SCRIPT
 */

// Product Database for Detailed Modals
const productDatabase = {
  'royal-majestic': {
    title: 'Royal Majestic Triple-Door Almirah',
    category: 'Home Almirahs',
    price: '₹14,500',
    specs: {
      'Steel Material': 'Prime CRCA Heavy Steel Sheet',
      'Gauge Thickness': '20 Gauge (Door & Outer Body)',
      'Dimensions': '78" Height x 48" Width x 21" Depth',
      'Surface Finish': '7-Tank Anti-Rust Epoxy Powder Coated',
      'Locking Mechanism': 'Ultra-Secure 3-Way Shoot Bolt Brass Lock',
      'Interior Layout': 'Full hanging rod, 4 deep shelves, secret jewel locker, mirror',
      'Warranty': '10-Year Structural Guarantee'
    },
    description: 'Our flagship home wardrobe engineered for maximum security, heavy storage capacity, and royal elegance. Features high-tensile hinges, dual-tone exterior with anti-scratch coating, and an integrated jewelry vault.'
  },
  'office-cabinet': {
    title: 'Executive 4-Drawer Lateral Filing Cabinet',
    category: 'Office Storage',
    price: '₹8,800',
    specs: {
      'Steel Material': 'Cold Rolled Prime CRCA Steel',
      'Gauge Thickness': '20 & 22 Gauge Heavy Duty',
      'Dimensions': '52" Height x 18" Width x 25" Depth',
      'Slide Mechanism': '3-Section Heavy Duty Ball Bearing Telescopic Runners',
      'Locking System': 'Single Key Central Locking for All Drawers',
      'Drawer Capacity': '50 kg per drawer weight capacity',
      'Warranty': '7-Year Commercial Warranty'
    },
    description: 'Designed for high-traffic corporate offices, accounting firms, and clinics. Keeps documents completely organized with anti-tilt safety (only one drawer opens at a time to prevent tipping).'
  },
  'slotted-rack': {
    title: 'Industrial Slotted Angle Multi-Tier Rack',
    category: 'Warehouse & Retail',
    price: '₹3,900',
    specs: {
      'Angle Section': '40mm x 40mm x 2.0mm Slotted Heavy Angles',
      'Panel Thickness': '18 & 20 Gauge Cold Rolled Shelves with Stiffener Ribs',
      'Standard Dimensions': '72" Height x 36" Width x 18" Depth (5 Shelves)',
      'Load Rating': '120 kg - 250 kg per shelf (Uniform Distributed Load)',
      'Finish': 'Industrial Powder Coated in Machine Grey / Blue',
      'Customization': 'Fully adjustable shelf levels every 2 inches'
    },
    description: 'The backbone of warehouses, auto spare shops, hardware stores, and retail showrooms. Modular, reconfigurable, and reinforced with bottom and top corner gusset plates for rock-solid stability.'
  },
  'titan-bed': {
    title: 'Titan King/Queen Steel Bed with Storage',
    category: 'Metal Beds',
    price: '₹11,200',
    specs: {
      'Frame Material': 'Heavy-Gauge Rectangular & Square Steel Pipes',
      'Gauge Thickness': '16 & 18 Gauge Heavy Frame',
      'Dimensions': 'Standard King (78" x 72") or Queen (78" x 60")',
      'Storage Type': 'Hydraulic Lift-Up or Sliding Box Storage Options',
      'Load Capacity': 'Tested for 450+ kg static weight',
      'Acoustic Design': 'Rubberized anti-squeak silent nylon bushings',
      'Warranty': '10-Year Frame Warranty'
    },
    description: 'Say goodbye to termite worries and squeaky wood. The Titan Steel Bed combines rugged structural steel with contemporary powder-coated aesthetics, suitable for modern homes, guest houses, and hostels.'
  },
  'steel-lockers': {
    title: 'Modular 6/12 Compartment Steel Lockers',
    category: 'Institutional & Gym',
    price: '₹9,500',
    specs: {
      'Steel Material': 'CRCA Heavy Sheet with Welded Monobloc Construction',
      'Door Variants': '4, 6, 9, 12, or 18 Compartments',
      'Security': 'Individual Cam Lock with Duplicate Master Keys or Padlock Hasp',
      'Ventilation': 'Laser-cut ventilation louvers on each compartment door',
      'Dimensions': '78" Height x 36" Width x 18" Depth',
      'Warranty': '5-Year Commercial Warranty'
    },
    description: 'Essential for gyms, factories, schools, colleges, and staff change rooms. Provides tamper-proof personal storage with name-card slots and clothes hanging pegs inside each compartment.'
  },
  'classic-wardrobe': {
    title: 'Classic 2-Door Wardrobe with Locker',
    category: 'Home Almirahs',
    price: '₹10,400',
    specs: {
      'Steel Material': 'Prime CRCA 20/22 Gauge',
      'Dimensions': '72" Height x 36" Width x 19" Depth',
      'Finish': 'Polyester Powder Coated (Glossy / Matte)',
      'Storage': '4 Shelves, 1 Hanging Rod, 1 In-Built Lockable Safe',
      'Locking': '6-Lever Heavy Brass Lock',
      'Warranty': '10-Year Warranty'
    },
    description: 'A timeless staple for every family bedroom. Compact footprint with smartly optimized vertical storage for clothes, blankets, cash, and valuables.'
  }
};

// DOM Content Loaded
document.addEventListener('DOMContentLoaded', () => {
  initMobileNav();
  initCategoryFilter();
  initQuoteCalculator();
  initFaqAccordion();
  initContactForm();
});

/* =========================================================
   1. MOBILE NAVBAR
   ========================================================= */
function initMobileNav() {
  const navToggle = document.getElementById('navToggle');
  const navLinks = document.getElementById('navLinks');
  const links = document.querySelectorAll('.nav-link');

  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      navLinks.classList.toggle('show');
    });

    links.forEach(link => {
      link.addEventListener('click', () => {
        navLinks.classList.remove('show');
      });
    });
  }
}

/* =========================================================
   2. CATEGORY FILTER TABS
   ========================================================= */
function initCategoryFilter() {
  const filterBtns = document.querySelectorAll('.filter-btn');
  const productCards = document.querySelectorAll('.product-card');

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filter = btn.getAttribute('data-filter');

      productCards.forEach(card => {
        const category = card.getAttribute('data-category');
        if (filter === 'all' || category === filter) {
          card.style.display = 'flex';
          card.style.opacity = '1';
        } else {
          card.style.display = 'none';
          card.style.opacity = '0';
        }
      });
    });
  });
}

/* =========================================================
   3. PRODUCT DETAIL MODAL
   ========================================================= */
function openProductModal(productId) {
  const product = productDatabase[productId];
  if (!product) return;

  const modal = document.getElementById('productModal');
  const modalBody = document.getElementById('modalBody');

  let specsHtml = '';
  for (const [key, val] of Object.entries(product.specs)) {
    specsHtml += `
      <tr>
        <td style="padding: 0.6rem 0.75rem; border-bottom: 1px solid #e2e8f0; font-weight: 600; color: #475569; width: 40%;">${key}</td>
        <td style="padding: 0.6rem 0.75rem; border-bottom: 1px solid #e2e8f0; color: #0f172a;">${val}</td>
      </tr>
    `;
  }

  const encodedMsg = encodeURIComponent(
    `Hello New Steel Furniture, I want to inquire about the *${product.title}* (${product.price}). Please share catalog & final quote.`
  );

  modalBody.innerHTML = `
    <span class="product-category" style="font-weight: 700; color: #2563eb; text-transform: uppercase; font-size: 0.8rem;">${product.category}</span>
    <h2 style="font-size: 1.6rem; margin: 0.35rem 0 0.85rem; color: #0f172a;">${product.title}</h2>
    <div style="font-size: 1.35rem; font-weight: 800; color: #2563eb; margin-bottom: 1rem;">Starting from ${product.price}</div>
    <p style="color: #64748b; font-size: 0.95rem; margin-bottom: 1.5rem; line-height: 1.6;">${product.description}</p>
    
    <h4 style="margin-bottom: 0.65rem; font-size: 1.05rem;">Technical Specifications:</h4>
    <table style="width: 100%; border-collapse: collapse; margin-bottom: 2rem; font-size: 0.88rem; background: #f8fafc; border-radius: 8px; overflow: hidden;">
      <tbody>
        ${specsHtml}
      </tbody>
    </table>

    <div style="display: flex; gap: 1rem; flex-wrap: wrap;">
      <a href="https://wa.me/919876543210?text=${encodedMsg}" target="_blank" class="btn btn-whatsapp-full" style="flex: 1;">
        Inquire / Order on WhatsApp
      </a>
      <a href="tel:+919876543210" class="btn btn-outline" style="padding: 0.8rem 1.25rem;">
        📞 Call Factory
      </a>
    </div>
  `;

  modal.classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closeProductModal() {
  const modal = document.getElementById('productModal');
  if (modal) {
    modal.classList.remove('active');
    document.body.style.overflow = 'auto';
  }
}

// Close modal when clicking outside
window.addEventListener('click', (e) => {
  const modal = document.getElementById('productModal');
  if (e.target === modal) {
    closeProductModal();
  }
});

/* =========================================================
   4. INTERACTIVE PRICE ESTIMATOR
   ========================================================= */
function initQuoteCalculator() {
  const categorySelect = document.getElementById('calcCategory');
  const gaugeSelect = document.getElementById('calcGauge');
  const finishSelect = document.getElementById('calcFinish');
  const qtyInput = document.getElementById('calcQty');
  const qtyMinus = document.getElementById('qtyMinus');
  const qtyPlus = document.getElementById('qtyPlus');
  const totalDisplay = document.getElementById('calcTotal');
  const bulkTag = document.getElementById('bulkDiscountTag');
  const btnShareWhatsApp = document.getElementById('btnShareWhatsApp');

  function calculate() {
    const selectedCat = categorySelect.options[categorySelect.selectedIndex];
    const basePrice = parseFloat(selectedCat.getAttribute('data-base')) || 10000;

    const selectedGauge = gaugeSelect.options[gaugeSelect.selectedIndex];
    const gaugeMultiplier = parseFloat(selectedGauge.getAttribute('data-mult')) || 1.0;

    const selectedFinish = finishSelect.options[finishSelect.selectedIndex];
    const finishExtra = parseFloat(selectedFinish.getAttribute('data-extra')) || 0;

    let qty = parseInt(qtyInput.value) || 1;
    if (qty < 1) qty = 1;
    if (qty > 100) qty = 100;
    qtyInput.value = qty;

    // Unit Price Calculation
    let unitPrice = (basePrice * gaugeMultiplier) + finishExtra;

    // Bulk discount logic
    let discount = 0;
    if (qty >= 10) {
      discount = 0.12; // 12% off for 10+ units
      bulkTag.textContent = '12% Bulk Wholesale Discount Applied!';
      bulkTag.style.background = '#dcfce7';
      bulkTag.style.color = '#15803d';
    } else if (qty >= 3) {
      discount = 0.05; // 5% off for 3-9 units
      bulkTag.textContent = '5% Multi-Unit Discount Applied!';
      bulkTag.style.background = '#e0f2fe';
      bulkTag.style.color = '#0369a1';
    } else {
      bulkTag.textContent = 'Standard Factory Rate';
      bulkTag.style.background = '#f1f5f9';
      bulkTag.style.color = '#475569';
    }

    let totalPrice = (unitPrice * qty) * (1 - discount);
    totalDisplay.textContent = '₹' + Math.round(totalPrice).toLocaleString('en-IN');
  }

  categorySelect.addEventListener('change', calculate);
  gaugeSelect.addEventListener('change', calculate);
  finishSelect.addEventListener('change', calculate);

  qtyMinus.addEventListener('click', () => {
    let current = parseInt(qtyInput.value) || 1;
    if (current > 1) {
      qtyInput.value = current - 1;
      calculate();
    }
  });

  qtyPlus.addEventListener('click', () => {
    let current = parseInt(qtyInput.value) || 1;
    if (current < 100) {
      qtyInput.value = current + 1;
      calculate();
    }
  });

  // WhatsApp spec sharing
  btnShareWhatsApp.addEventListener('click', () => {
    const catName = categorySelect.options[categorySelect.selectedIndex].text;
    const gaugeName = gaugeSelect.options[gaugeSelect.selectedIndex].text;
    const finishName = finishSelect.options[finishSelect.selectedIndex].text;
    const qty = qtyInput.value;
    const estimatedTotal = totalDisplay.textContent;

    const message = `Hello New Steel Furniture!%0A%0A*I calculated an estimate on your website:*%0A` +
      `📦 *Item:* ${encodeURIComponent(catName)}%0A` +
      `🔩 *Steel Gauge:* ${encodeURIComponent(gaugeName)}%0A` +
      `🎨 *Finish:* ${encodeURIComponent(finishName)}%0A` +
      `🔢 *Quantity:* ${qty} unit(s)%0A` +
      `💰 *Estimated Total:* ${estimatedTotal}%0A%0A` +
      `Please confirm availability, delivery timeline, and best quotation.`;

    window.open(`https://wa.me/919876543210?text=${message}`, '_blank');
  });

  calculate();
}

/* =========================================================
   5. FAQ ACCORDION
   ========================================================= */
function initFaqAccordion() {
  const faqItems = document.querySelectorAll('.faq-item');

  faqItems.forEach(item => {
    const questionBtn = item.querySelector('.faq-question');
    const answer = item.querySelector('.faq-answer');

    questionBtn.addEventListener('click', () => {
      const isOpen = item.classList.contains('open');

      // Close all other items
      faqItems.forEach(otherItem => {
        otherItem.classList.remove('open');
        otherItem.querySelector('.faq-answer').style.maxHeight = null;
      });

      if (!isOpen) {
        item.classList.add('open');
        answer.style.maxHeight = answer.scrollHeight + 'px';
      }
    });
  });
}

/* =========================================================
   6. CONTACT FORM
   ========================================================= */
function initContactForm() {
  const contactForm = document.getElementById('contactForm');
  const successBanner = document.getElementById('formSuccessMessage');

  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();

      const name = document.getElementById('userName').value.trim();
      const phone = document.getElementById('userPhone').value.trim();
      const city = document.getElementById('userCity').value.trim();
      const interest = document.getElementById('userInterest').value;
      const message = document.getElementById('userMessage').value.trim();

      if (!name || !phone) {
        alert('Please enter your name and phone number.');
        return;
      }

      // Show instant success feedback
      successBanner.style.display = 'block';
      contactForm.reset();

      // Optionally offer to also launch WhatsApp with the filled details
      setTimeout(() => {
        const confirmWhatsapp = confirm('Inquiry registered! Would you like to chat with our workshop directly on WhatsApp right now?');
        if (confirmWhatsapp) {
          const waText = encodeURIComponent(
            `Hello New Steel Furniture, my name is ${name} (${city || 'City'}). I am inquiring about *${interest}*. Notes: ${message || 'Please send brochure & prices.'}`
          );
          window.open(`https://wa.me/919876543210?text=${waText}`, '_blank');
        }
      }, 500);
    });
  }
}
